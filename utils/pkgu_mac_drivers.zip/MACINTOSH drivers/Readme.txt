MaxStream XStream-PKG-U Macintosh Mac OS X Driver Installation
==============================================================

This installer works with Mac OS X.  Contact MaxStream support if you need a driver for Mac OS 8/9.

This driver causes the MaxStream XStream-PKG-U

Installing the FTDIUSBSerialDriver
Expand the archive FTDIUSBSerialDriver.pkg.sit, then run the installer by double-clicking on the FTDIUSBSerialDriver.pkg icon.  When the installation is complete, reboot the computer.

After rebooting, open the FTDIREEN.DMG (FTDI ReEnumerate.dmg) disk image.  Copy these files into the folder /Library/Startup Items/FTDIReEnumerate
This file is a script that re-enumerates the XStream-PKG-U after a reboot.  Technical explanation: this is necessary because the FTDIUSBSerialDriver has a dependency on com.apple.iokit.IOSerialFamily, which is not available at boot time.

Plug in the MaxStream XStream-PKG-U.  When properly installed and plugged in, you will see the following new entries in the /dev directory:

/dev/cu.usbserial-xxxxxxxx

/dev/tty.usbserial-xxxxxxxx

xxxxxxxx is a location string that depends on where in the USB "tree" the device is connected.

The MaxStream XStream-PKG-U has been tested on Mac OS X 10.2.x using the terminal to communicate with the device.

The MaxStream XStream-PKG-U has also been tested with National Instruments LabVIEW 7, using the VISA serial VIs.


Troubleshooting
===============

1. The device does not appear in the /dev directory or the text "New Port Detected" is not displayed in System Preferences - Network.

Ensure that you have installed the supplied driver.  The download available from FTDI (the maker of the USB chipset in the XStream-PKG-U) does not support the MaxStream XStream-PKG-U directly.  Ensure that you have rebooted the computer and plugged in the device after rebooting.